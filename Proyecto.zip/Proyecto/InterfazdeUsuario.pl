:- use_module(library(pce)).
:- pce_image_directory('./imagenes').
:- use_module(library(pce_style_item)).
:- dynamic color/2.
/* Declaraciones de recursos de imágenes */
resource(img_principal, image, image('img_principal.jepg')).
resource(portada, image, image('portada.jpg')).


/* Funciones para mostrar imágenes */
mostrar_imagen(Pantalla, Imagen) :-
    new(Figura, figure),
    new(Bitmap, bitmap(resource(Imagen), @on)),
    send(Bitmap, name, 1),
    send(Figura, display, Bitmap),
    send(Figura, status, 1),
    send(Pantalla, display, Figura, point(100, 80)).

mostrar_imagen_tratamiento(Pantalla, Imagen) :-
    new(Figura, figure),
    new(Bitmap, bitmap(resource(Imagen), @on)),
    send(Bitmap, name, 1),
    send(Figura, display, Bitmap),
    send(Figura, status, 1),
    send(Pantalla, display, Figura, point(20, 100)).

nueva_imagen(Ventana, Imagen) :-
    new(Figura, figure),
    new(Bitmap, bitmap(resource(Imagen), @on)),
    send(Bitmap, name, 1),
    send(Figura, display, Bitmap),
    send(Figura, status, 1),
    send(Ventana, display, Figura, point(0, 0)).

imagen_pregunta(Ventana, Imagen) :-
    new(Figura, figure),
    new(Bitmap, bitmap(resource(Imagen), @on)),
    send(Bitmap, name, 1),
    send(Figura, display, Bitmap),
    send(Figura, status, 1),
    send(Ventana, display, Figura, point(500, 60)).




botones :-
    borrado,
    send(@boton, free),
    send(@btntratamiento, free),
    mostrar_diagnostico(Enfermedad),
    send(@texto, selection('El Diagnostico a partir de los datos es:')),
    send(@resp1, selection(Enfermedad)),
    new(@boton, button('Iniciar consulta',
                       message(@prolog, botones))),
    new(@btntratamiento, button('Detalles y Tratamiento',
                                message(@prolog, mostrar_tratamiento, Enfermedad))),
    send(@main, display, @boton, point(20, 450)),
    send(@main, display, @btntratamiento, point(138, 450)).

mostrar_tratamiento(X) :-
    new(@tratam, dialog('Tratamiento')),
    send(@tratam, append, label(nombre, 'Explicacion: ')),
    send(@tratam, display, @lblExp1, point(70, 51)),
    send(@tratam, display, @lblExp2, point(50, 80)),
    tratamiento(X),
    send(@tratam, transient_for, @main),
    send(@tratam, open_centered).

tratamiento(X) :-
    send(@lblExp1, selection('De Acuerdo Al Diagnostico El Tratamiento Es:')),
    mostrar_imagen_tratamiento(@tratam, X).

crea_interfaz_inicio:- new(@interfaz,dialog('Plagas y Enfermedades Citricos',
  size(1000,1000))),

  mostrar_imagen(@interfaz, portada),

  new(BotonComenzar,button('COMENZAR',and(message(@prolog,interfaz_principal) ,
  and(message(@interfaz,destroy),message(@interfaz,free)) ))),
  new(BotonSalir,button('SALIDA',and(message(@interfaz,destroy),message(@interfaz,free)))),
  send(@interfaz,append(BotonComenzar)),
  send(@interfaz,append(BotonSalir)),
  send(@interfaz,open_centered).

  :-crea_interfaz_inicio, consult('Shell.pl'), consult('BaseConocimientos.pl').
