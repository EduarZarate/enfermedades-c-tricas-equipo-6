conocimiento('plaga_a',
['¿Se observa la presencia de insectos en las hojas?', 
'¿Se notan mordeduras o áreas dañadas en las hojas?',
'¿Las hojas muestran decoloración o manchas anormales?',
'¿Se observa la caída prematura de frutas o flores?']).

conocimiento('plaga_b',
['¿Se detecta la presencia de insectos en la corteza del árbol?',
'¿Hay presencia de secreciones o residuos en la corteza o ramas?',
'¿Se perciben agujeros o marcas en la corteza?',
'¿Se presenta debilidad o marchitez en las ramas o hojas?']).

conocimiento('enfermedad_a',
['¿Se observan manchas anormales o decoloración en las hojas?',
'¿Las hojas presentan deformidades o crecimiento anómalo?',
'¿Se detectan zonas de podredumbre o necrosis en las ramas o frutas?',
'¿Se observa exudación o sustancias extrañas en las ramas o tronco?']).

% Asocia preguntas con identificadores de imágenes

id_imagen_preg('¿Se observa la presencia de insectos en las hojas?', 'insectos_en_hojas').
id_imagen_preg('¿Se notan mordeduras o áreas dañadas en las hojas?', 'mordeduras_hojas').
id_imagen_preg('¿Las hojas muestran decoloración o manchas anormales?', 'decoloracion_hojas').
id_imagen_preg('¿Se observa la caída prematura de frutas o flores?', 'caida_prematura_frutas').
id_imagen_preg('¿Se detecta la presencia de insectos en la corteza del árbol?', 'insectos_en_corteza').
id_imagen_preg('¿Hay presencia de secreciones o residuos en la corteza o ramas?', 'secreciones_corteza').
id_imagen_preg('¿Se perciben agujeros o marcas en la corteza?', 'agujeros_corteza').
id_imagen_preg('¿Se presenta debilidad o marchitez en las ramas o hojas?', 'debilidad_marchitez').
id_imagen_preg('¿Se observan manchas anormales o decoloración en las hojas?', 'manchas_anormales_hojas').
id_imagen_preg('¿Las hojas presentan deformidades o crecimiento anómalo?', 'deformidades_hojas').
id_imagen_preg('¿Se detectan zonas de podredumbre o necrosis en las ramas o frutas?', 'podredumbre_necrosis').
id_imagen_preg('¿Se observa exudación o sustancias extrañas en las ramas o tronco?', 'exudacion_sustancias').
